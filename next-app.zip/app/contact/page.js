import Contact from "@/components/contact/Contact";

export default function ContactPage() {
    return (
        <Contact />
    )
}