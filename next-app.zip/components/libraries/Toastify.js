"use client"

import { ToastContainer } from 'react-toastify';

export default ToastContainer;